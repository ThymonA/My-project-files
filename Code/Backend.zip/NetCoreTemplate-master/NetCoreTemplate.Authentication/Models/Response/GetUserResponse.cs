﻿namespace NetCoreTemplate.Authentication.Models.Response
{
    public class GetUserResponse
    {
        public string Firstname { get; set; }

        public string Lastname { get; set; }

        public string Email { get; set; }
    }
}
