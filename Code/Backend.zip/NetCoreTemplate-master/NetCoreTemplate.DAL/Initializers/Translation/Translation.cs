﻿namespace NetCoreTemplate.DAL.Initializers.Translation
{
    public class Translation
    {
        public string Key { get; set; }

        public string NL { get; set; }

        public string EN { get; set; }

        public string DE { get; set; }

        public string FR { get; set; }
    }
}
