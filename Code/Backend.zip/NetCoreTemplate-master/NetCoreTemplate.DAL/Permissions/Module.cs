﻿namespace NetCoreTemplate.DAL.Permissions
{
    public enum Module
    {
        Dashboard = 1,
    }
}
