﻿namespace NetCoreTemplate.DAL.Permissions
{
    public enum Type
    {
        Role = 1,
        Roles = 2,
        User = 3,
        Users = 4
    }
}
