﻿namespace NetCoreTemplate.ViewModels.General
{
    using NetCoreTemplate.ViewModels.Base;

    public sealed class RoleListViewModel : BaseAuthenticationListViewModel<RoleViewModel>
    {
    }
}
