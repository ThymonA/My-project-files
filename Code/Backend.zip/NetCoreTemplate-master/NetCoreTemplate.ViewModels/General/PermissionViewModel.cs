﻿namespace NetCoreTemplate.ViewModels.General
{
    public class PermissionViewModel
    {
        public int Id { get; set; }

        public string Action { get; set; }

        public bool Active { get; set; }
    }
}
