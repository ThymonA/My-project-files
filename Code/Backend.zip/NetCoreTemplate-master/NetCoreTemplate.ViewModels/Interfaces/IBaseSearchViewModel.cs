﻿namespace NetCoreTemplate.ViewModels.Interfaces
{
    public interface IBaseSearchViewModel
    {
        string SearchTerm { get; set; }
    }
}
