﻿namespace NetCoreTemplate.ViewModels.Controllers.Error
{
    using NetCoreTemplate.ViewModelProcessors.Base;

    public sealed class BaseErrorViewModel : BaseViewModel
    {
        public int Code { get; set; }
    }
}
