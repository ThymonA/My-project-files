﻿namespace NetCoreTemplate.ViewModels.Controllers.Error
{
    using NetCoreTemplate.ViewModels.Base;

    public class AuthErrorViewModel : BaseAuthenticationViewModel
    {
        public int Code { get; set; }
    }
}
