﻿namespace NetCoreTemplate.ViewModels.Controllers.Dashboard
{
    using NetCoreTemplate.ViewModels.Base;

    public class HomeViewModel : BaseAuthenticationViewModel
    {
    }
}
